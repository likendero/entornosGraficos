package ejercicio1;

import javax.swing.JFrame;

public class Ej1Ventana extends JFrame {
	/**
	 * metodo constructor que crea la ventana
	 */
	public Ej1Ventana() {
		super();
		// definicion del tamanno
		setBounds(100, 100, 400, 400);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
	}
	
}
